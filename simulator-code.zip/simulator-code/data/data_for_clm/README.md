# 文件说明
mode = train,test,dev
{mode}.txt：   用于训练
{mode}.source：用于推理输入
{mode}.target：用于推理eval


task = NLU,POL,NLG
{mode}-{task}.txt:    用于训练
{mode}-{task}.source：用于推理输入
{mode}-{task}.target：用于推理eval