modelname="EleutherAI/gpt-neo-1.3B"
savename="gpt-neo-1b"
dataset="./data/data_for_clm"

python run_clm.py \
    --model_name_or_path $modelname \
    --dataset_dir $dataset \
    --per_device_train_batch_size 8 \
    --per_device_eval_batch_size 8 \
    --num_train_epochs 40 \
    --do_train \
    --do_eval \
    --warmup_steps=100 \
    --gradient_accumulation_steps=4 \
    --learning_rate=1e-4 \
    --save_steps 100 \
    --output_dir "clm-output/"$savename \
    --overwrite_output_dir \
    --save_total_limit 10 \

